//
//  TWTRCoreLanguage.h
//  TwitterCore
//
//  Created by Manuel Deschamps on 6/5/15.
//  Copyright (c) 2015 Twitter Inc. All rights reserved.
//

@interface TWTRCoreLanguage : NSObject

+ (NSString *)preferredLanguage;

@end
